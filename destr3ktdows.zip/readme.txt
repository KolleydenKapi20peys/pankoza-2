destr3ktdows.exe by pankoza
Made in: C++
This is very dangerous for the non-safety version (but the safety version is SAFE)
The non-safety version will disable your task manager and damage the MBR
Needs Visual Studio 2015 redist x86
stay away from this malware (even from safety version) if you have epilepsy or heart problems
the creator is not responsible for any damages